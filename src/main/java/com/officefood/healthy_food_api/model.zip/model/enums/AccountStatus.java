package com.officefood.healthy_food_api.model.enums;

public enum AccountStatus { ACTIVE, SUSPENDED, DELETED }
