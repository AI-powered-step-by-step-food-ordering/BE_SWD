package com.officefood.healthy_food_api.model.enums;

public enum Role { ADMIN, STAFF, USER }
