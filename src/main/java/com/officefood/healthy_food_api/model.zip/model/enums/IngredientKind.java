package com.officefood.healthy_food_api.model.enums;

public enum IngredientKind { CARB, PROTEIN, VEGGIE, SAUCE, TOPPING, OTHER }
