package com.officefood.healthy_food_api.model.enums;

public enum OrderStatus { PENDING, CONFIRMED, IN_KITCHEN, READY_FOR_PICKUP, COMPLETED, CANCELLED }
