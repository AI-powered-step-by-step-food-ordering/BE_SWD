package com.officefood.healthy_food_api.model.enums;

public enum PromotionType { PERCENT_OFF, AMOUNT_OFF, BXGY, FREE_ITEM, DELIVERY_CREDIT }
