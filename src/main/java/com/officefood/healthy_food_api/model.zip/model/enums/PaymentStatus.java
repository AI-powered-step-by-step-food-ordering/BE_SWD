package com.officefood.healthy_food_api.model.enums;

public enum PaymentStatus { PENDING, AUTHORIZED, CAPTURED, REFUNDED, FAILED, CANCELLED }
