package com.officefood.healthy_food_api.model.enums;

public enum PaymentMethod { CARD, CASH, WALLET, TRANSFER }
