package com.officefood.healthy_food_api.model.enums;

public enum JobStatus { QUEUED, PREPPING, DONE, HANDED_OVER, CANCELLED }
