package com.officefood.healthy_food_api.model.enums;

public enum RedemptionStatus { APPLIED, VOIDED }
