package com.officefood.healthy_food_api.model.enums;

public enum StockAction { RECEIPT, ADJUSTMENT_PLUS, ADJUSTMENT_MINUS, RESERVATION, CONSUMPTION, RETURN_IN, RETURN_OUT }
